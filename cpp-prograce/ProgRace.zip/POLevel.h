#ifndef POLEVEL_H
#define POLEVEL_H

#include <QPixmap>
#include <QRect>
#include <vector>

class PObject;
class PObjectView;

typedef std::vector<PObject *>		POMutableArray;
typedef POMutableArray::iterator	PObjectEnumerator;
typedef const POMutableArray		POArray;

class POLevel
{
	PObjectView		*view;			// the object view
	POMutableArray		obstacles;		// foreground objects
	POMutableArray		backgroundObjects;	// background objects
	QPixmap			obstacleImage;		// standard obstacle
	QPixmap			backgroundObjectImage;	// moving bg image
	double			bgSpeed;		// background speed
	double			fgSpeed;		// foreground speed
	double			targetSpeed;		// new object speed
	int			numObjects;		// current object count

public:
	POLevel(PObjectView *oView);
	~POLevel();

	void repositionBackgroundObject(PObject * object);
	void repositionObject(PObject * object);
	void addNewObject();
	void setSizeRect(const QRect &obstRec);

	POMutableArray &getObjects();
	POMutableArray &getBackgroundObjects();
};

#endif // POLEVEL_H
