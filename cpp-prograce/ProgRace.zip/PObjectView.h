#ifndef POBJECTVIEW_H
#define POBJECTVIEW_H

#include <QGraphicsView>

class Controller;

class PObjectView: public QGraphicsView
{
	Q_OBJECT

	Controller *delegate;

public:
	PObjectView(QWidget *parent = 0);

	void setController(Controller *controller);
	void mousePressEvent(QMouseEvent *ev);
};

#endif // POBJECTVIEW_H
