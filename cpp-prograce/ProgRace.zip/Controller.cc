#include "Controller.h"
#include "PObjectView.h"
#include "PObject.h"
#include "POLevel.h"
#include "POSound.h"

#include <string>
#include <iostream>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <sstream>

using namespace std;

#define SHIPYPOS	40		// ship y position
#ifndef FPS
#define FPS		30.0		// frames per second
#endif
#define FRAMESPEED	(1000.0/FPS)
#define SPEEDUPFACTOR	1.1		// ship collision speedup factor

#define SHIP_WIDTH	90
#define SHIP_HEIGHT	55


/*
 * implement Controller and initial variables
 */
Controller::Controller(QMainWindow *parent): QMainWindow(parent)
{
	setupComplete = false;
	gameRunning = false;
	setupUi(this);
	objectView->setController(this);

	ship = new PObject(":/Ship.tiff");
	shipSize = ship->pixmap().size();

	swooshSound = new POSound("Swoosh.wav");
	crashSound  = new POSound("Crash.wav");
	
	// get the player name
	cout << "Please enter a name: ";
	cin >> name;

	QString nameStr = QString("%1").arg(name.c_str());
	nameText -> setText(nameStr);

	nofGame = 0;

	ifstream fin(name.c_str());
	string line;	
	
	//if the file is existed
	//store the records into the array and sorting the array
	if(fin.is_open())
	{				
		getline(fin, line);		
		while(!fin.eof())
    		{
			stringstream ss(line);	
			ss >> convert;	
			scores[nofGame] = convert;
			nofGame ++;
			getline(fin, line);
    		}
		
		bubbleSort();
	}
	//else create a file for new player's records
	else{
		ofstream fmake;
		fmake.open(name.c_str());	
		fmake.close();
	}
	fin.close();
	
	awakeFromNib();
}

/*
 * destructor for Controller
 */
Controller::~Controller()
{
	delete gameTimer;
	delete ship;
	delete currentLevel;
	delete swooshSound;
	delete crashSound;
}

/*
 *  sorting the scores from the highest to the lowest
 */
void Controller::bubbleSort()
{
	int temp;

	for(int i = 0; i < nofGame-1; i++)
	{
		for(int j = 0; j < nofGame-i-1; j++)
		{
			if(scores[j+1] > scores[j])
			{
				temp = scores[j];
				scores[j] = scores[j+1];
				scores[j+1] = temp;
		 	}
                 }
	}

	cout << "Number of Games Played: " << nofGame << endl;

	for(int a = 0; a < nofGame; a++)
	{
		cout << scores[a] << endl;
	} 
}


/*
 * set window visible
 * create the scene
 * setup the elements
 */
void Controller::awakeFromNib()
{
	show();

#ifndef ALLOW_RESIZE	// use fixed size by default
	setFixedSize(size());
	QRectF maxScene(childrenRect());
#else
	QRectF maxScene(0, 0, 3072, 2048);
#endif
	QGraphicsScene *scene = new QGraphicsScene(maxScene);
	objectView->setScene(scene);
	scene->addItem(ship);
	ship->setZValue(3.0);			// make this the topmost object
	viewDimensions = childrenRect();
	shipIsVisible = true;
	hiddenShipCountDown = 0;

	conditionSetup();		
	
	if(nofGame > 0){
		rankScores();		//rank the scores and show on the game panel
	}
	
		
	/*
	 * create a new level (the default level)
	 */
	currentLevel = new POLevel(objectView);

	/*
	 * create a new timer
	 */
	gameTimer = new QTimer;
		
	gameTimer->setInterval(static_cast<int>(FRAMESPEED));
	gameTimer->setSingleShot(false);
	connect(gameTimer, SIGNAL(timeout()), this, SLOT(moveObjects()));
	gameTimer->start();

	setupComplete = true;
}


/*
 * ship is collision with some asteroid
 */
void Controller::collisionWithObject(PObject *)
{
	shipIsVisible = false;
	ship->setCoords(-2*ship->getSize().width(), ship->coords().y());
	crashSound->play();	
	crashSound->stop();
	hiddenShipCountDown = static_cast<int>(1 * FPS);
	
	//reduce 1 live per collision
	//if used up the live set the game over
	if(--live <= 0)
	{
	
		scores[nofGame] = score;
				
		nofGame ++;
		
		bubbleSort();
			
		
		//write new score to the current record
		ofstream fout;				
		fout.open(name.c_str());			
		for(int i = 0; i < nofGame; i++) 
		{
			fout << scores[i] << "\n";
		} 
		fout.close();
	
		setupComplete = false;
		gameRunning = false;
		
		gameTimer->stop();
		
		delete currentLevel;
		delete gameTimer;

		restart();
	}	
}

/*
 * rank the scores from the highest to the lowest
 * also calculate the avgerage score from the record
 */
void Controller::rankScores()
{
	highScore = scores[0];
	QString highScoreStr = QString::number(highScore);
	highScoreText -> setText(highScoreStr);
			
	if(nofGame > 1)
	{
		lowScore = scores[nofGame-1];
		QString lowScoreStr = QString::number(lowScore);
		lowScoreText -> setText(lowScoreStr);
	}

	totalScore = 0;
	for(int i = 0; i < nofGame; i++){
		totalScore += scores[i];
	}

	avgScore = totalScore / nofGame;

	QString avgScoreStr = QString("%1").arg(avgScore);
	avgScoreText -> setText(avgScoreStr);
}

/*
 * game condition set up
 */
void Controller::conditionSetup()
{
	level = 1;	
	score = 0;	
	live = 3;
	
	QString levelStr = QString::number(level);
	levelText -> setText(levelStr);
	
	QString liveStr = QString::number(live);
	liveText -> setText(liveStr);

	QString scoreStr = QString::number(score);
	scoreText -> setText(scoreStr);

	levelUp = false;
}

/*
 * move the background,
 * the foreground
 * and the ship
 */
void Controller::moveObjects()
{
	repositionShip();

	if (hiddenShipCountDown)
	{
		if (--hiddenShipCountDown <= 0)
			makeShipAppear();
	}

	PObjectEnumerator e = currentLevel->getBackgroundObjects().begin();
	while (e != currentLevel->getBackgroundObjects().end())
	{
		PObject *object = *e++;		// get next background object
		object->move();			// move the background object

		/*
		 * out of bounds?
		 */
		QRect dimensions = object->dimensions();
		if (dimensions.y()-dimensions.height() > viewDimensions.height())
			currentLevel->repositionBackgroundObject(object);
	}

	if (gameRunning)
	{
		PObject *collisionObject = NULL;

					
		/*
		 * move foreground objects and check for collision
		 */
		e = currentLevel->getObjects().begin();

		while (e != currentLevel->getObjects().end())
		{
			PObject *object = *e++;
			object->move();		// move the foreground object
			if (ship->hasCollisionWithObject(object))
			{
				collisionObject = object;
			}
			else			// check if there
			{
				QRect dimensions = object->dimensions();

				if (dimensions.y() >= viewDimensions.height() - SHIPYPOS &&
				    dimensions.y() < viewDimensions.height() - SHIPYPOS + object->getVelocity().y())
				{
					swooshSound->play();
					
					if (shipIsVisible)
					{		
						score += 20;
						QString scoreStr = QString::number(score);
						scoreText -> setText(scoreStr);
						
						checkLevelUp();						
					}	
				}
				if (dimensions.y() > viewDimensions.height())
				{
					currentLevel->repositionObject(object);
				}
			}			
		}

		//add an extra asteroid each level up
		if(levelUp)
		{
			currentLevel->addNewObject();
			
			levelUp = false;
		}

		//ship collision with some asteroid
		if (collisionObject)
		{
			collisionWithObject(collisionObject);

			QString liveStr = QString::number(live);
			liveText->setText(liveStr);
		}
	}
}


/*
 * check the current score
 */
void Controller::checkLevelUp()
{
	if(score%100 == 0)
	{
		level ++;			
		QString levelStr = QString::number(level);
		levelText -> setText(levelStr);
		
		levelUp = true;
	}
}

/*
 * reset the game
 */
void Controller::restart()
{	
	show();

#ifndef ALLOW_RESIZE	// use fixed size by default
	setFixedSize(size());
	QRectF maxScene(childrenRect());
#else
	QRectF maxScene(0, 0, 3072, 2048);
#endif
	QGraphicsScene *scene = new QGraphicsScene(maxScene);
	objectView->setScene(scene);
	scene->addItem(ship);
	ship->setZValue(3.0);			// make this the topmost object
	viewDimensions = childrenRect();
	shipIsVisible = true;
	hiddenShipCountDown = 0;

	conditionSetup();		
	
	//rank the scores and show on the game panel
	rankScores();
		
	/*
	 * create a new level
	 */
	currentLevel = new POLevel(objectView);

	/*
	 * create a new timer
	 */
	gameTimer = new QTimer;

	gameTimer->setInterval(static_cast<int>(FRAMESPEED));
	gameTimer->setSingleShot(false);
	connect(gameTimer, SIGNAL(timeout()), this, SLOT(moveObjects()));
	gameTimer->start();

	setupComplete = true;
}


/*
 * trace the mouse cursor position to make the ship moving
 */
void Controller::repositionShip()
{
	if (shipIsVisible)
	{
		QPoint mousePos = QCursor::pos();
		int newX = mousePos.x() - x() - shipSize.width()/2;

		QPoint position(newX, 0);
		setShipPosition(position);
	}
}

/*
 * start the game
 */
void Controller::startGame()
{
	if (!setupComplete)	// ignore any events before setup has completed
		return;

	if (gameRunning)	// ignore start envents if the game is running
		return;

	swooshSound->play();
	gameRunning = true;
}

/*
 * resize the object view
 */
void Controller::resizeEvent(QResizeEvent *)
{
	if (!setupComplete)	// ignore any events before setup has completed
		return;

	viewDimensions = childrenRect();
	objectView->resize(viewDimensions.width(), viewDimensions.height());
	//scoreLabel->resize(viewDimensions.width() - 2 * scoreLabel->x(), scoreLabel->height());

	if (currentLevel)
		currentLevel->setSizeRect(viewDimensions);
}

/*
 * set the ship moving
 */
void Controller::setShipPosition(QPoint position)
{
	position.setY(objectView->height() - shipSize.height() - SHIPYPOS);
	shipPosition = position;
	if (shipIsVisible)
	{
		/*
		 * prevent the ship from leaving the window
		 */
		if (position.x() < 0)
		{
			position.setX(0);
		}
		else if (position.x() > objectView->width() - SHIP_WIDTH)
		{
			position.setX(objectView->width() - SHIP_WIDTH);
		}
		
		ship->setCoords(position.x(), position.y());
	}
}

/*
 * set the ship appear
 */
void Controller::makeShipAppear()
{
	shipIsVisible = true;
	repositionShip();
}
