#include "Controller.h"

/*
 * invoke ProgRace
 */
int main(int argc, char *argv[])
{
	QApplication app(argc, argv);
	Controller *controller = new Controller;

	int rv = app.exec();

	delete controller;

	return rv;
}
