#ifndef POBJECT_H
#define POBJECT_H

#include <QGraphicsPixmapItem>
#include <QSize>
#include <QPointF>

// macro to check for collision between two QRects
#define INTERSECTS(o,b)	((o).y() < (b).y() + (b).height() && \
(o).y() + (o).height() > (b).y() && \
(o).x() + (o).width()  > (b).x() && \
(o).x() < (b).x() + (b).width())

class PObject: public QGraphicsPixmapItem 
{
	QPixmap originalImage;			// the image to display
	QSize size;				// size of the object
	QPointF position;			// position of the object
	QPointF velocity;			// current speed

public:
	PObject(const char *file);
	PObject(const QPixmap &pixmap);

	void initWithImage(const QPixmap &pixmap);

	void setSize(int w, int h);
	void setSize(const QSize &newSize);
	QSize &getSize();			// return the object size
	QRect dimensions();			// return the position and size

	PObject *hasCollisionWithObject(PObject *obj);

	void setVelocity(const QPointF &speed);
	QPointF getVelocity();
	const QPointF &coords();		// return the object position
	void setCoords(const QPointF &newPos);
	void setCoords(qreal x, qreal y);
	void move();				// move object
};

#endif // POBJECT_H
