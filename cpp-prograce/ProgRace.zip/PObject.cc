#include "PObject.h"

#define MAXVELOCITY 10

/*
 * retrieve the object image
 */
PObject::PObject(const char *file)
{
	QPixmap pixmap(file);

	initWithImage(pixmap);
}


PObject::PObject(const QPixmap &pixmap)
{
	initWithImage(pixmap);
}

void PObject::initWithImage(const QPixmap &pixmap)
{
	originalImage = pixmap;
	setPixmap(pixmap);
	size = pixmap.size();
}

/*
 * set the size
 */
void PObject::setSize(int w, int h)
{
	QPixmap pixmap = originalImage.scaled(w, h);
	setPixmap(pixmap);
	size = pixmap.size();
}


void PObject::setSize(const QSize &newSize)
{
	setSize(newSize.width(), newSize.height());
}


QSize &PObject::getSize()
{
	return size;
}


/*
 * set the coordinate
 */
void PObject::setCoords(qreal x, qreal y)
{
	position.setX(x);
	position.setY(y);

	QGraphicsPixmapItem::setPos(position);
}


void PObject::setCoords(const QPointF &pos)
{
	QGraphicsPixmapItem::setPos(position = pos);
}


const QPointF &PObject::coords()
{
	return position;
}


QRect PObject::dimensions()
{
	QRect dim(static_cast<int>(position.x()), static_cast<int>(position.y()),
		  static_cast<int>(size.width()), static_cast<int>(size.height()));

	return dim;
}

/*
 * set the moving speed
 */
void PObject::setVelocity(const QPointF &speed)
{
	velocity = speed;
}


QPointF PObject::getVelocity()
{
	return velocity;
}


void PObject::move()
{
	position += velocity;

	QGraphicsPixmapItem::setPos(position);
}


PObject *PObject::hasCollisionWithObject(PObject *obj)
{
	QRect myDim  = dimensions();
	QRect objDim = obj->dimensions();

	if (INTERSECTS(myDim, objDim))
		return this;

	return NULL;
}
