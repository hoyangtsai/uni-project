#include <cstdio>
#include <qsound.h>
#include "POSound.h"

// search path for resource files
static const char *search[] =
{
".", "English.lproj", "Resources", "Resources/English.lproj",
"..", "../../English.lproj", "../../../../../English.lproj",
NULL
};

static const char *sep[] = { "/", "\\", NULL };

static QSound *loadSound(const char *fileName)
{
	FILE *file;
	
	int i, j;
	for (i = 0; search[i]; i++) for (j = 0; sep[j]; j++)
	{
		std::string path(search[i]);
		path.append(sep[j]);
		path.append(fileName);
		
		// does the given file exist?
		if ((file = fopen(path.c_str(), "rb")) != NULL)
		{
			fclose(file);
			return new QSound(path.c_str());
		}
	}
	
	return NULL;
}


POSound::POSound(const char *fileName)
{
	if ((qSound = loadSound(fileName)) != NULL)
	{
		qSound->play();		// cache sound
		qSound->stop();
	}
}


POSound::~POSound()
{
	if (qSound) delete qSound;
}


void POSound::play()
{
	if (qSound) qSound->play();
}


void POSound::stop()
{
	if (qSound) qSound->stop();
}
