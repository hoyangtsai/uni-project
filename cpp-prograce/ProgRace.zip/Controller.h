#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <QTimer>
#include "ui_ProgRace.h"

class PObject;
class POLevel;
class POSound;

class Controller: public QMainWindow, private Ui::MainWindow
{
	Q_OBJECT

	QRect		viewDimensions;		// size of the view
	PObject		*ship;			// the main ship

	POSound		*swooshSound;		// the "plop" sound
	POSound		*crashSound;		// the "clonk" sound
	QTimer		*gameTimer;		// this makes the game tick

	POLevel		*currentLevel;
	QSize		shipSize;		// current ship size
	QPoint		shipPosition;		// current ship position
	bool		gameRunning;		// game currently running?
	bool		shipIsVisible;		// is the ship visible?
	bool		setupComplete;		// is setup completed?

	int		hiddenShipCountDown;	// count down till ship appears

	std::string	name;
		
	int		convert;

	int		live;			// a number of lives
	int		score;			// a score per game
	int		level;
		
	bool		levelUp;

	int		scores[100];

	int		highScore;
	int		lowScore;
	int		nofGame;
	int		totalScore;
	double		avgScore;


public:
	Controller(QMainWindow *parent = 0);
	~Controller();

	void startGame();
	void resizeEvent(QResizeEvent *);
		
	void restart();
	void checkLevelUp();
	void bubbleSort();
	void conditionSetup();
	void rankScores();

protected:
	void awakeFromNib();

	void repositionShip();
	void collisionWithObject(PObject *obj);
	void setShipPosition(QPoint position);
	void makeShipAppear();

private slots:
	void moveObjects();
};
#endif
