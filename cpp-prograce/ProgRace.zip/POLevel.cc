#include <cstdlib>
#include <ctime>
#include "POLevel.h"
#include "PObject.h"
#include "PObjectView.h"

#ifndef VELOCITY_X			// initial speed
#define VELOCITY_X		0.0
#define VELOCITY_Y		4.0
#define BG_VELOCITY_Y		1.0
#define BG_RANDOMNESS		1.0e-9
#define FG_RANDOMNESS		1.0e-8
#define SIZE_MIN		32
#define	SIZE_VARIATION		128
#define NUM_BG_IMAGES		30	// number of background images
#define MAX_OBJECTS		20	// maximum number of obstacles
#define MAX_SPEED		10
#define FG_SPEEDUP		1.0002
#define BG_SPEEDUP		1.0001	// level continuous speedup factor
#define NEW_OBJECT_TARGET	1.005	// createnew object when reached
#define NEW_OBJECT_FACTOR	1.1	// factor for next target
#endif

#ifdef WIN32
#define random	rand
#define srandom	srand
#undef	BG_RANDOMNESS
#define BG_RANDOMNESS		(4.0*BG_VELOCITY_Y/RAND_MAX)
#undef	FG_RANDOMNESS
#define FG_RANDOMNESS		(4.0*VELOCITY_Y/RAND_MAX)
#endif

// macro to limit x to a value from l to h
#define LIMIT(x,l,h)	((x) = ((x) < (l)) ? (l) : ((x) > (h) ? (h) : (x)))


POLevel::POLevel(PObjectView *oView): obstacleImage(":/Obstacle.tiff"),
				      backgroundObjectImage(":/Star.tiff")
{
	numObjects = 0;
	bgSpeed = fgSpeed = 1.0;
	targetSpeed = NEW_OBJECT_TARGET;

	view = oView;
	QRectF frame = view->sceneRect();

	/*
	 * make the background black
	 */
	QPalette palette(view->window()->palette());
	palette.setColor(QPalette::Background, Qt::black);
	view->window()->setPalette(palette);

	palette = view->palette();
	palette.setColor(QPalette::Background, Qt::black);
	view->setPalette(palette);

	/*
	 * create background objects
	 */
	int width =  static_cast<int>(frame.size().width());
	int height = static_cast<int>(frame.size().height());
	
	srandom(time(NULL));
	for (int i = 0; i < NUM_BG_IMAGES; i++)
	{
		int x = random() % width;
		int y = random() % height;
		
		PObject *star = new PObject(backgroundObjectImage);

		if (star)
		{
			double speed = BG_VELOCITY_Y + random() * BG_RANDOMNESS;
			QPointF velocity(0, speed);

			star->setCoords(x, y);
			star->setVelocity(velocity);
			backgroundObjects.push_back(star);
			view->scene()->addItem(star);
			star->setZValue(0.0);		// below anything else
		}
	}
	
	/*
	 * create an initial obstacle
	 */
	addNewObject();

	setSizeRect(view->geometry());
}


void POLevel::setSizeRect(const QRect & /*obstRec*/)
{
	//
	// here you can resize objects when the window gets resized
	//

}

/*
 * set the stars size and speed
 */
void POLevel::repositionBackgroundObject(PObject * object)
{
	QRectF frame = view->sceneRect();
	int width =  static_cast<int>(frame.size().width());
	int height = static_cast<int>(frame.size().height());
	int x =  random() % width;
	int y = -random() % height;
	double speed = bgSpeed * (BG_VELOCITY_Y + random() * BG_RANDOMNESS);

	QPointF velocity(0, speed);
	
	object->setCoords(x, y);
	object->setVelocity(velocity);

	if (bgSpeed < MAX_SPEED)
		bgSpeed *= BG_SPEEDUP;

	if (fgSpeed < MAX_SPEED)
		fgSpeed *= FG_SPEEDUP;

	if (fgSpeed > targetSpeed)
	{
		addNewObject();
		targetSpeed *= NEW_OBJECT_FACTOR;
	}
}

/*
 * set the obstacles size and speed
 */
void POLevel::repositionObject(PObject *object)
{
	QRectF frame = view->sceneRect();
	int width  = static_cast<int>(frame.size().width());
	int height = static_cast<int>(frame.size().height());
	int x =  random() % width;
	int y = -random() % height;
	double speed = fgSpeed * (VELOCITY_Y + random() * FG_RANDOMNESS);

	QPointF velocity(VELOCITY_X, speed);

	object->setCoords(x, y);
	object->setVelocity(velocity);
}

/*
 * add new obstacle
 */
void POLevel::addNewObject()
{
	if (numObjects >= MAX_OBJECTS) return;	// limit reached?
	numObjects++;
	
	PObject *obstacle = new PObject(obstacleImage);

	if (obstacle)
	{
		QRectF frame = view->sceneRect();
		int size = SIZE_MIN + random() % SIZE_VARIATION;
		int width  = static_cast<int>(frame.size().width()) - size;
		int height = static_cast<int>(frame.size().height());
		int x = random() % width;
		int y = -size - random() % height;
		double speed = fgSpeed * (VELOCITY_Y + random() * FG_RANDOMNESS);
		
		QSize obstacleSize(size, size);
		QPointF velocity(VELOCITY_X, speed);
		
		obstacle->setCoords(x, y);
		obstacle->setVelocity(velocity);
		
		obstacle->setSize(obstacleSize);		
		obstacles.push_back(obstacle);
		view->scene()->addItem(obstacle);
		obstacle->setZValue(1.0);		// above stars
 	}
}

/*
 * return the obstacles
 */
POMutableArray &POLevel::getObjects()
{
	return obstacles;
}

/*
 * return the stars
 */
POMutableArray &POLevel::getBackgroundObjects()
{
	return backgroundObjects;
}


POLevel::~POLevel()
{
	PObjectEnumerator enumerator = obstacles.begin();
	while (enumerator != obstacles.end())
		delete *enumerator++;		// delete obstacle

	enumerator = backgroundObjects.begin();
	while (enumerator != backgroundObjects.end())
		delete *enumerator++;		// delete background object
}
