#include <QMouseEvent>
#include "PObjectView.h"
#include "Controller.h"

PObjectView::PObjectView(QWidget *parent): QGraphicsView(parent)
{

}


void PObjectView::setController(Controller *controller)
{
	delegate = controller;
}

/*
 * start the game by mouse clicking
 */
void PObjectView::mousePressEvent(QMouseEvent *)
{
	if (delegate)
		delegate->startGame();
}

