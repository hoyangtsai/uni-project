#ifndef POSOUND_H
#define POSOUND_H

class QSound;

class POSound
{
	QSound	*qSound;		// QT sound class

public:
	POSound(const char *fileName);
	virtual ~POSound();

	void play();
	void stop();
};

#endif // POSOUND_H
